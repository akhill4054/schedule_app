import 'package:flutter/material.dart';

class AppTheme {
  final Color _accentColor;
  final Color _primary;
  final Color _primaryVariant;

  AppTheme(
      {Color accentColor = const Color.fromARGB(255, 113, 96, 243),
      Color primary = const Color(0xffee2ee2),
      Color primaryVariant = const Color(0xffa42fdb)})
      : _accentColor = accentColor,
        _primary = primary,
        _primaryVariant = primaryVariant;

  ThemeData getLightTheme() {
    return ThemeData.light().copyWith(
        accentColor: _accentColor,
        appBarTheme: AppBarTheme(
          elevation: 0,
          backgroundColor: Colors.transparent,
          brightness: Brightness.light,
          iconTheme: IconThemeData(color: Colors.black87),
        ),
        buttonColor: _accentColor,
        colorScheme: ColorScheme.light().copyWith(
          primary: _primary,
          primaryVariant: _primaryVariant,
        ));
  }

  ThemeData getDarkTheme() => ThemeData.dark().copyWith(
        accentColor: _accentColor,
      );
}
