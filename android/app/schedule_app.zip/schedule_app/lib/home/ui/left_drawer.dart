import 'package:flutter/material.dart';
import 'package:flutter_inner_drawer/inner_drawer.dart';
import 'package:lottie/lottie.dart';
import 'package:schedule_app/auth/ui/login.dart';

class LeftDrawerPage extends StatelessWidget {
  final GlobalKey<InnerDrawerState> _drawerKey;

  LeftDrawerPage({GlobalKey<InnerDrawerState> drawerKey})
      : _drawerKey = drawerKey {
    assert(_drawerKey != null);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: Icon(Icons.arrow_back_ios),
              onPressed: () => {
                _drawerKey.currentState.close(
                  direction: InnerDrawerDirection.start,
                )
              },
            ),
          ],
        ),
        body: Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            bottom: 8,
          ),
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: DrawerLoginPage(),
              ),
              Divider(
                height: 10,
              ),
              Expanded(
                flex: 1,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    ListTile(
                      leading: Icon(Icons.settings),
                      title: Text('Settings'),
                      onTap: () => {},
                    ),
                    ListTile(
                      leading: Icon(Icons.info_outline_rounded),
                      title: Text('About'),
                      onTap: () => {},
                    ),
                    ListTile(
                      leading: Icon(Icons.help_outline_rounded),
                      title: Text('Help'),
                      onTap: () => {},
                    ),
                    ListTile(
                      leading: Icon(Icons.share_rounded),
                      title: Text('Share the app'),
                      onTap: () => {},
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.bottomRight,
                        child: IconButton(
                          onPressed: () => {},
                          icon: Lottie.asset(
                            'assets/lottie/moon.json',
                            width: 40,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
