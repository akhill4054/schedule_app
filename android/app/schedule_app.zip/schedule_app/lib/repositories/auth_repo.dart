import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

enum AuthenticationState { authenticated, unauthenticated }

class AuthRepository {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final _controller = StreamController<AuthenticationState>();

  void signInWithPhoneNumber(
    String code,
    String number,

  ) {
    _auth.verifyPhoneNumber(
      phoneNumber: '$code$number',
      timeout: Duration(seconds: 30),
      verificationCompleted: (firebaseUser) {},
      codeSent: (verificationId, [forceResendingToken]) async {
        // Sign the user in (or link) with the credential
        await _auth.signInWithPhoneNumber(
            verificationId: verificationId, smsCode: 'smsCode');
      },
      verificationFailed: (error) {},
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<FirebaseUser> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication googleAuth =
        await googleUser.authentication;

    // Once signed in, return the UserCredential
    return await _auth.signInWithGoogle(
      idToken: googleAuth.idToken,
      accessToken: googleAuth.idToken,
    );
  }

  void signOut() async {
    await _auth.signOut();
    _controller.add(AuthenticationState.unauthenticated);
  }

  void dispose() => _controller.close();
}
