import 'package:schedule_app/models/user.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PrefsManager {
  static const _keyUser = "user";

  Future<User> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    String userJson = prefs.getString(_keyUser);

    if (userJson?.isNotEmpty == true) {
      return User.fromJson(userJson);
    } else {
      return null;
    }
  }

  void setUser(User user) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(_keyUser, user.toJsonString());
  }
}