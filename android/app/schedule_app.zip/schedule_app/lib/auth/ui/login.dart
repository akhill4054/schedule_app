import 'package:flutter/material.dart';

class DrawerLoginPage extends StatelessWidget {
  const DrawerLoginPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final accentColor = Theme.of(context).accentColor;

    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 165,
            margin: EdgeInsets.all(24),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: accentColor,
                width: 5,
              ),
            ),
            child: CircleAvatar(
              radius: 70,
              backgroundImage:
                  AssetImage('assets/image/profile_placeholder.jpg'),
            ),
          ),
          ElevatedButton(
            child: Text(
              'Log In',
              style: TextStyle(fontSize: 20),
            ),
            style: ElevatedButton.styleFrom(
                elevation: 0,
                padding: EdgeInsets.symmetric(horizontal: 32, vertical: 8),
                primary: accentColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                )),
            onPressed: () => {
              showModalBottomSheet(
                context: context,
                builder: (context) {
                  return LoginBottomSheetPage();
                },
              )
            },
          ),
          Container(
            margin: EdgeInsets.only(top: 8),
            child: Text('Login to do more.'),
          ),
        ],
      ),
    );
  }
}

class LoginBottomSheetPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
